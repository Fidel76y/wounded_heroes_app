package com.example.wounded_heroes_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
